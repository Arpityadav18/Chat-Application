
# Chat Application with Socket.IO Chat

A simple chat demo for Socket.IO

# How to use
$ npm i
$ npm start


And point your browser to `http://localhost:3000`. Optionally, specify


